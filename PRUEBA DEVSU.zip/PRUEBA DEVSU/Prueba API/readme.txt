Descargar archivo zip
Ir a la carpeta Prueba API y abrir un CMD
Asegurarse que tengan instalado Java17 y Maven
Ejecutar en CMD el comando mvn clean install para instalar las dependencias
Ejecutar en CMD el comando mvn test
Dentro de la carpeta Prueba API, abrir la carpeta target, dentro de esta carpeta abrir la carpeta kareate-reports
Dentro de karate-reports se encuentra el archivo karate-summary.html, abrir el archivo en el navegador
En el navegador se visualizará los dos casos de prueba ejecutados, pueden elegirlos para analizar
