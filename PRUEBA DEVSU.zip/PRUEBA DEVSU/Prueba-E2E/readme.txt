Asegurarse tener instalada la versión de node.js mayor o igual a 17
Ubicarse en la carpeta Prueba-E2E
Abrir la ventana CMD
Ejecutar el comando npm install cypress --save-dev para instalar Cypress
Ejecutar el comando npx cypress open para abrir Cypress
En la ventana de cypress, elegimos E2E Testing
Seleccionar navegador y presionar el botón Start E2E…
Se abre el navegador seleccionado
Dar click en archivo spec.cy.js
Empieza la ejecución de las pruebas
